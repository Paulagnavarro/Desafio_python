from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep

# Inicializando o WebDriver
driver = webdriver.Chrome()

# Acessando o site do Mercado Livre
driver.get("https://www.mercadolivre.com.br")
sleep(3)

# Função para coletar produtos
def coletar_produtos():
    products = driver.find_elements(By.CLASS_NAME, 'ui-search-result')
    if not products:
        print("Nenhum produto encontrado.")
    for product in products:
        try:
            title = product.find_element(By.CLASS_NAME, 'ui-search-item__title').text
            price = product.find_element(By.CLASS_NAME, 'ui-search-price__price').text
            print(f'Título: {title}, Preço: {price}')
        except Exception as e:
            print(f"Erro ao coletar produto: {e}")

# Função para buscar e coletar resultados do filtro "Mais relevantes"
def buscar_e_coletar_mais_relevantes():
    input1 = driver.find_element(By.TAG_NAME, 'input')
    input1.clear()
    input1.send_keys('funko')
    input1.send_keys(Keys.ENTER)
    sleep(3)

    print("\nResultados para 'Mais relevantes' - Página 1:")
    coletar_produtos()

    for _ in range(2):  # Percorre as 2 próximas páginas (total de 3 páginas)
        try:
            next_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'andes-pagination__link') and contains(@title, 'Seguinte')]"))
            )
            next_button.click()
            sleep(3)
            print(f"Resultados para 'Mais relevantes' - Página seguinte:")
            coletar_produtos()
        except Exception as e:
            print("Não há mais páginas ou erro ao acessar: ", e)
            break

# Função para buscar e coletar resultados do filtro "Menor preço"
def buscar_e_coletar_menor_preco():
    input1 = driver.find_element(By.TAG_NAME, 'input')
    input1.clear()
    input1.send_keys('funko')
    input1.send_keys(Keys.ENTER)
    sleep(3)

    try:
        ordenar_menu = driver.find_element(By.XPATH, "//button[contains(@class, 'andes-dropdown__trigger')]")
        ordenar_menu.click()
        sleep(1)

        filtro_element = driver.find_element(By.XPATH, "//span[contains(text(), 'Menor preço')]")
        filtro_element.click()
        sleep(3)

        print("\nResultados para 'Menor preço' - Página 1:")
        coletar_produtos()

        for _ in range(2):  # Percorre as 2 próximas páginas (total de 3 páginas)
            try:
                next_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'andes-pagination__link') and contains(@title, 'Seguinte')]"))
                )
                next_button.click()
                sleep(3)
                print(f"Resultados para 'Menor preço' - Página seguinte:")
                coletar_produtos()
            except Exception as e:
                print("Não há mais páginas ou erro ao acessar: ", e)
                break

    except Exception as e:
        print(f"Erro ao aplicar filtro 'Menor preço': {e}")

# Função para buscar e coletar resultados do filtro "Maior preço"
def buscar_e_coletar_maior_preco():
    input1 = driver.find_element(By.TAG_NAME, 'input')
    input1.clear()
    input1.send_keys('funko')
    input1.send_keys(Keys.ENTER)
    sleep(3)

    try:
        ordenar_menu = driver.find_element(By.XPATH, "//button[contains(@class, 'andes-dropdown__trigger')]")
        ordenar_menu.click()
        sleep(1)

        filtro_element = driver.find_element(By.XPATH, "//span[contains(text(), 'Maior preço')]")
        filtro_element.click()
        sleep(3)

        print("\nResultados para 'Maior preço' - Página 1:")
        coletar_produtos()

        while True:
            try:
                next_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//a[contains(@class, 'andes-pagination__link') and contains(@title, 'Seguinte')]"))
                )
                next_button.click()
                sleep(3)
                print(f"Resultados para 'Maior preço' - Página seguinte:")
                coletar_produtos()
            except Exception as e:
                print("Não há mais páginas ou erro ao acessar: ", e)
                break

    except Exception as e:
        print(f"Erro ao aplicar filtro 'Maior preço': {e}")

# Coletar resultados do filtro "Mais relevantes"
buscar_e_coletar_mais_relevantes()

# Coletar resultados do filtro "Menor preço"
buscar_e_coletar_menor_preco()

# Coletar resultados do filtro "Maior preço"
buscar_e_coletar_maior_preco()

# Fechando o navegador
driver.close()
